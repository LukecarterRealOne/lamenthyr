# Lamenthyr (Forge 1.20.1)

A red television with eyes that move.

> It fell. A burning creature. It screamed my name.
> IT BURNS

## The item: Red Television
| Action | What happens |
|---|---|
| Right-click | **The Scream.** Everyone within 48 blocks sees THEIR OWN name screamed at them (title + "IT BURNS"). Everything within 12 blocks catches fire (not you). 20 s cooldown. |
| Right-click a player | **Eat.** Their face is covered by a black square on every client, their nameplate becomes a row of black blocks, and they are blinded and slowed for 4 s. Lasts through death and relogging. 10 s cooldown. |
| Sneak + right-click an eaten player | The TV spits them out. |

The item texture is animated (the eyes dart around and blink). After it has eaten at least one player it switches to a bloodshot version with a black censor square on the screen. Hold SHIFT on the tooltip for the full "Genesis" text.

Recipe (shaped): lightning rod on top, ender eye + black stained glass + ender eye in the middle, three redstone blocks along the bottom.

Test commands (op): `/give @s lamenthyr:red_television`, `/lamenthyr eat <player>`, `/lamenthyr release <player>`.

## Build the jar
**No installs? Let GitHub build it**
1. Make a new GitHub repo and upload everything in this folder (including the hidden `.github` folder).
2. Open the Actions tab and wait for "Build mod jar" to finish (about 5 minutes).
3. Open the run, scroll to Artifacts, download `lamenthyr-jar`. The zip contains `lamenthyr-1.0.0.jar`.

**Locally:** JDK 17 and Gradle 8.1.1, then `gradle build`. The jar is `build/libs/lamenthyr-1.0.0.jar`.

Drop the jar in `.minecraft/mods` with Forge 1.20.1 (47.x). Every player needs the mod to see the black squares.
