package com.lamenthyr.mod;

import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Lamenthyr.MODID)
public final class ServerEvents {
    private ServerEvents() {}

    /** A client started seeing this player: tell it if they are eaten. */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer subject
                && event.getEntity() instanceof ServerPlayer viewer
                && CensorData.isEaten(subject)) {
            CensorData.sendTo(viewer, subject);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp && CensorData.isEaten(sp)) {
            CensorData.resync(sp);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp && CensorData.isEaten(sp)) {
            CensorData.resync(sp);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp && CensorData.isEaten(sp)) {
            CensorData.resync(sp);
        }
    }

    /** Being eaten survives death. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (event.getOriginal().getPersistentData().getBoolean(CensorData.KEY)) {
            event.getEntity().getPersistentData().putBoolean(CensorData.KEY, true);
        }
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("lamenthyr")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("eat")
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ctx -> {
                                    ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                                    CensorData.set(target, true);
                                    ctx.getSource().sendSuccess(() ->
                                            Component.literal("\u25AE\u25AE\u25AE\u25AE\u25AE was eaten.")
                                                    .withStyle(ChatFormatting.DARK_RED), true);
                                    return 1;
                                })))
                .then(Commands.literal("release")
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ctx -> {
                                    ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                                    CensorData.set(target, false);
                                    ctx.getSource().sendSuccess(() ->
                                            Component.literal(target.getName().getString() + " was spat out.")
                                                    .withStyle(ChatFormatting.GRAY), true);
                                    return 1;
                                }))));
    }
}
