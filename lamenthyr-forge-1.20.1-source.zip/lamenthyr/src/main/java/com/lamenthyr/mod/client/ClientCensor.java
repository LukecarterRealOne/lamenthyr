package com.lamenthyr.mod.client;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Client-side set of players whose faces are currently eaten. */
public final class ClientCensor {
    private static final Set<UUID> EATEN = new HashSet<>();

    private ClientCensor() {}

    public static void set(UUID id, boolean eaten) {
        if (eaten) {
            EATEN.add(id);
        } else {
            EATEN.remove(id);
        }
    }

    public static boolean has(UUID id) {
        return EATEN.contains(id);
    }

    public static void clear() {
        EATEN.clear();
    }
}
