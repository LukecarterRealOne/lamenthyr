package com.lamenthyr.mod;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Lamenthyr: a red television with eyes that move. It screams your name, and it eats faces. */
@Mod(Lamenthyr.MODID)
public class Lamenthyr {
    public static final String MODID = "lamenthyr";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<Item> RED_TELEVISION = ITEMS.register("red_television",
            () -> new RedTelevisionItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));

    public Lamenthyr() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        bus.addListener(this::addToCreativeTab);
        Net.init();
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(RED_TELEVISION);
        }
    }
}
