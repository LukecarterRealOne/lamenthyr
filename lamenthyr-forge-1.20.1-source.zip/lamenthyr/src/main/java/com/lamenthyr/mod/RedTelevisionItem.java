package com.lamenthyr.mod;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * The Red Television.
 *  - Right-click: THE SCREAM. Everyone nearby sees their own name screamed at them, and everything close burns.
 *  - Right-click a player: EAT. Their face is replaced by a black square. Sneak + right-click to spit them out.
 */
public class RedTelevisionItem extends Item {
    public static final String TAG_EATEN = "Eaten";

    private static final double SCREAM_RANGE = 48.0;
    private static final double BURN_RANGE = 12.0;
    private static final int SCREAM_COOLDOWN = 400; // 20 s
    private static final int EAT_COOLDOWN = 200;    // 10 s

    private static final String BLOCKS = "\u25AE\u25AE\u25AE\u25AE\u25AE\u25AE\u25AE\u25AE";

    private static final String[] SHORT_LORE = {
            "In the beginning, when God? created me",
            "me", "me", "me",
            BLOCKS,
            "It fell. A burning creature. It screamed my name."
    };

    private static final String[] FULL_LORE = {
            "In the beginning, when God? created me",
            "me", "me", "me",
            BLOCKS,
            "",
            "a lizard?bird?\u25AE\u25AE\u25AE?",
            "flew?walked?swam? down to you?.",
            "Sometimes?? Maybe it was never. Although, you?",
            "don't know, you didn't check to see if it was.",
            "And he?she?it? was free, free to do what he?she?it?",
            "willed, and yet he?she?it? didn't, for there was",
            "no message that foretold.",
            "",
            "It fell. A burning creature. It screamed my name.",
            "Or, well, so I thought, but it turns out we all",
            "heard it scream our own name. We're walking over",
            "to check it out. It's so stupid, they have no idea",
            "whats over there. Why am I even walking with them??",
            "I know this won't end well."
    };

    public RedTelevisionItem(Properties properties) {
        super(properties);
    }

    // ------------------------------------------------------------------ tooltip
    @Override
    @OnlyIn(Dist.CLIENT)
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Genesis \u2022 O").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
        boolean full = Screen.hasShiftDown();
        for (String line : full ? FULL_LORE : SHORT_LORE) {
            tooltip.add(Component.literal(line).withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
        }
        tooltip.add(Component.literal("IT BURNS").withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
        tooltip.add(Component.empty());
        tooltip.add(Component.literal("Right-click: it screams your name").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Right-click a player: it eats their face").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Sneak + right-click an eaten player: spit them out").withStyle(ChatFormatting.GRAY));
        int eaten = stack.hasTag() ? stack.getTag().getInt(TAG_EATEN) : 0;
        if (eaten > 0) {
            tooltip.add(Component.literal("Eaten: " + eaten).withStyle(ChatFormatting.DARK_RED));
        }
        if (!full) {
            tooltip.add(Component.literal("Hold SHIFT to read it all").withStyle(ChatFormatting.DARK_GRAY));
        }
    }

    // ------------------------------------------------------------------ the scream
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.pass(stack);
        }
        if (!level.isClientSide && level instanceof ServerLevel serverLevel) {
            scream(serverLevel, player);
            player.getCooldowns().addCooldown(this, SCREAM_COOLDOWN);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    private void scream(ServerLevel level, Player holder) {
        level.playSound(null, holder.blockPosition(), SoundEvents.GHAST_SCREAM, SoundSource.PLAYERS, 6.0F, 0.5F);
        level.playSound(null, holder.blockPosition(), SoundEvents.WARDEN_ROAR, SoundSource.PLAYERS, 6.0F, 0.6F);

        // every player in earshot hears it scream THEIR OWN name
        for (ServerPlayer p : level.players()) {
            if (p.distanceToSqr(holder) > SCREAM_RANGE * SCREAM_RANGE) continue;
            p.connection.send(new ClientboundSetTitlesAnimationPacket(4, 40, 20));
            p.connection.send(new ClientboundSetSubtitleTextPacket(
                    Component.literal("IT BURNS").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD)));
            p.connection.send(new ClientboundSetTitleTextPacket(
                    p.getName().copy().withStyle(ChatFormatting.RED, ChatFormatting.BOLD)));
        }

        // and it burns
        AABB box = holder.getBoundingBox().inflate(BURN_RANGE);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, mob -> mob != holder && mob.isAlive())) {
            e.setSecondsOnFire(6);
        }
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, holder.getX(), holder.getY() + 1.0, holder.getZ(),
                160, 3.0, 2.0, 3.0, 0.06);
        level.sendParticles(ParticleTypes.LAVA, holder.getX(), holder.getY() + 1.0, holder.getZ(),
                40, 2.0, 1.0, 2.0, 0.0);
    }

    // ------------------------------------------------------------------ the eating
    @Override
    public InteractionResult interactLivingEntity(ItemStack unused, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof ServerPlayer victim)) {
            // on the client, claim the click for players so the server decides
            return target instanceof Player ? InteractionResult.sidedSuccess(player.level().isClientSide) : InteractionResult.PASS;
        }
        ItemStack stack = player.getItemInHand(hand);
        if (victim == player || player.getCooldowns().isOnCooldown(this)) {
            return InteractionResult.PASS;
        }
        ServerLevel level = victim.serverLevel();

        if (CensorData.isEaten(victim)) {
            if (player.isShiftKeyDown()) {
                CensorData.set(victim, false);
                level.playSound(null, victim.blockPosition(), SoundEvents.PLAYER_BURP, SoundSource.PLAYERS, 1.0F, 0.5F);
                victim.sendSystemMessage(Component.literal("You were spat out.").withStyle(ChatFormatting.GRAY));
            } else {
                player.displayClientMessage(Component.literal("Already eaten.").withStyle(ChatFormatting.DARK_RED), true);
            }
            player.getCooldowns().addCooldown(this, 20);
            return InteractionResult.SUCCESS;
        }

        CensorData.set(victim, true);
        victim.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 0));
        victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
        level.playSound(null, victim.blockPosition(), SoundEvents.GENERIC_EAT, SoundSource.PLAYERS, 2.0F, 0.4F);
        level.playSound(null, victim.blockPosition(), SoundEvents.PLAYER_BURP, SoundSource.PLAYERS, 2.0F, 0.3F);
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, victim.getX(), victim.getY() + 1.6, victim.getZ(),
                60, 0.3, 0.4, 0.3, 0.05);

        victim.connection.send(new ClientboundSetTitlesAnimationPacket(0, 60, 20));
        victim.connection.send(new ClientboundSetTitleTextPacket(
                Component.literal(BLOCKS).withStyle(ChatFormatting.DARK_RED)));
        victim.sendSystemMessage(Component.literal(BLOCKS).withStyle(ChatFormatting.DARK_RED));

        if (level.getServer() != null) {
            level.getServer().getPlayerList().broadcastSystemMessage(
                    Component.literal("\u25AE\u25AE\u25AE\u25AE\u25AE was eaten.").withStyle(ChatFormatting.DARK_RED), false);
        }

        stack.getOrCreateTag().putInt(TAG_EATEN, stack.getOrCreateTag().getInt(TAG_EATEN) + 1);
        player.getCooldowns().addCooldown(this, EAT_COOLDOWN);
        return InteractionResult.SUCCESS;
    }
}
