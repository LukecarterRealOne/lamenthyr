package com.lamenthyr.mod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

/** Server-side "has been eaten" state. Stored in the player's persistent data so it survives relogs. */
public final class CensorData {
    public static final String KEY = "lamenthyr_eaten";

    private CensorData() {}

    public static boolean isEaten(Player player) {
        return player.getPersistentData().getBoolean(KEY);
    }

    /** Sets the state and tells every client that can see (or is) this player. */
    public static void set(ServerPlayer player, boolean eaten) {
        if (eaten) {
            player.getPersistentData().putBoolean(KEY, true);
        } else {
            player.getPersistentData().remove(KEY);
        }
        resync(player);
    }

    public static void resync(ServerPlayer player) {
        Net.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player),
                new CensorPacket(player.getUUID(), isEaten(player)));
    }

    /** Tells one specific client about one player's state. */
    public static void sendTo(ServerPlayer viewer, ServerPlayer subject) {
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> viewer),
                new CensorPacket(subject.getUUID(), isEaten(subject)));
    }
}
