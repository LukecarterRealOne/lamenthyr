package com.lamenthyr.mod;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Lamenthyr.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Net() {}

    public static void init() {
        CHANNEL.registerMessage(0, CensorPacket.class,
                CensorPacket::encode, CensorPacket::decode, CensorPacket::handle);
    }
}
