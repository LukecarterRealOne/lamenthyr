package com.lamenthyr.mod.client;

import com.lamenthyr.mod.Lamenthyr;
import com.lamenthyr.mod.RedTelevisionItem;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = Lamenthyr.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    /** Adds the censor square to both player models (classic "default" and slim "alex"). */
    @SubscribeEvent
    public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
        for (String skin : event.getSkins()) {
            EntityRenderer<? extends Player> renderer = event.getSkin(skin);
            if (renderer instanceof PlayerRenderer playerRenderer) {
                playerRenderer.addLayer(new CensorLayer(playerRenderer));
            }
        }
    }

    /** The television swaps to its bloodshot "fed" texture once it has eaten someone. */
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> ItemProperties.register(
                Lamenthyr.RED_TELEVISION.get(),
                new ResourceLocation(Lamenthyr.MODID, "fed"),
                (stack, level, entity, seed) ->
                        stack.hasTag() && stack.getTag().getInt(RedTelevisionItem.TAG_EATEN) > 0 ? 1.0F : 0.0F));
    }
}
