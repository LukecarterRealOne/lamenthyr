package com.lamenthyr.mod.client;

import com.lamenthyr.mod.Lamenthyr;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Draws a solid black square over the face of every eaten player. */
public class CensorLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation BLACK = new ResourceLocation(Lamenthyr.MODID, "textures/misc/black.png");

    // Head cube in model space (1 unit = 1 block, +Y is DOWN, the face looks toward -Z).
    // The head is x:-0.25..0.25, y:-0.5..0, z:-0.25..0.25; the hat layer reaches z=-0.28125.
    private static final float X = 0.27F;
    private static final float Y_TOP = -0.53F;
    private static final float Y_BOTTOM = 0.03F;
    private static final float Z_FRONT = -0.31F;
    private static final float Z_BACK = -0.285F;

    public CensorLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (player.isInvisible() || !ClientCensor.has(player.getUUID())) {
            return;
        }
        pose.pushPose();
        this.getParentModel().head.translateAndRotate(pose);
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(BLACK));
        PoseStack.Pose last = pose.last();

        // front (the visible square)
        quad(vc, last, light, -X, Y_TOP, Z_FRONT, X, Y_TOP, Z_FRONT, X, Y_BOTTOM, Z_FRONT, -X, Y_BOTTOM, Z_FRONT, 0, 0, -1);
        // back, so it never looks hollow from inside
        quad(vc, last, light, -X, Y_TOP, Z_BACK, X, Y_TOP, Z_BACK, X, Y_BOTTOM, Z_BACK, -X, Y_BOTTOM, Z_BACK, 0, 0, 1);
        // edges
        quad(vc, last, light, -X, Y_TOP, Z_FRONT, X, Y_TOP, Z_FRONT, X, Y_TOP, Z_BACK, -X, Y_TOP, Z_BACK, 0, -1, 0);
        quad(vc, last, light, -X, Y_BOTTOM, Z_FRONT, X, Y_BOTTOM, Z_FRONT, X, Y_BOTTOM, Z_BACK, -X, Y_BOTTOM, Z_BACK, 0, 1, 0);
        quad(vc, last, light, -X, Y_TOP, Z_FRONT, -X, Y_BOTTOM, Z_FRONT, -X, Y_BOTTOM, Z_BACK, -X, Y_TOP, Z_BACK, -1, 0, 0);
        quad(vc, last, light, X, Y_TOP, Z_FRONT, X, Y_BOTTOM, Z_FRONT, X, Y_BOTTOM, Z_BACK, X, Y_TOP, Z_BACK, 1, 0, 0);

        pose.popPose();
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int light,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4,
                             float nx, float ny, float nz) {
        vertex(vc, pose, light, x1, y1, z1, 0.0F, 0.0F, nx, ny, nz);
        vertex(vc, pose, light, x2, y2, z2, 1.0F, 0.0F, nx, ny, nz);
        vertex(vc, pose, light, x3, y3, z3, 1.0F, 1.0F, nx, ny, nz);
        vertex(vc, pose, light, x4, y4, z4, 0.0F, 1.0F, nx, ny, nz);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, int light,
                               float x, float y, float z, float u, float v, float nx, float ny, float nz) {
        vc.vertex(pose.pose(), x, y, z)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(pose.normal(), nx, ny, nz)
                .endVertex();
    }
}
