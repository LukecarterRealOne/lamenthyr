package com.lamenthyr.mod;

import com.lamenthyr.mod.client.ClientCensor;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Server to client: "this player is / is no longer eaten". */
public class CensorPacket {
    private final UUID player;
    private final boolean eaten;

    public CensorPacket(UUID player, boolean eaten) {
        this.player = player;
        this.eaten = eaten;
    }

    public static void encode(CensorPacket msg, FriendlyByteBuf buf) {
        buf.writeUUID(msg.player);
        buf.writeBoolean(msg.eaten);
    }

    public static CensorPacket decode(FriendlyByteBuf buf) {
        return new CensorPacket(buf.readUUID(), buf.readBoolean());
    }

    public static void handle(CensorPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientCensor.set(msg.player, msg.eaten)));
        ctx.get().setPacketHandled(true);
    }
}
